<?php $__env->startSection('titulo', 'EasyAppointments'); ?>



<?php $__env->startSection('title'); ?>
    titulo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('linkScript'); ?>

    <style>
        #calendar {
            height: 75vh;
            /* el calendario ocupará el 60% de la altura de la pantalla */
        }

        .fc-daygrid-day-number {
            color: black;
            text-decoration: none;
            /* Este estilo desactiva el subrayado de texto que se utiliza para los enlaces hipervínculos */
        }

        .fc-col-header-cell-cushion {
            cursor: default;
            pointer-events: none;
            color: black;
            text-decoration: none;
            /* Este estilo desactiva el subrayado de texto que se utiliza para los enlaces hipervínculos */
        }
    </style>



    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.6/index.global.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {

                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,listDay,listWeek'
                },

                // customize the button names,
                // otherwise they'd all just say "list"
                views: {
                    listDay: {
                        buttonText: 'list day'
                    },
                    listWeek: {
                        buttonText: 'list week'
                    },
                    dayGridMonth: {
                        buttonText: 'month'
                    }
                },

                initialView: 'listDay',
                initialDate: new Date().toISOString().slice(0, 10),
                navLinks: true,
                editable: false,
                dayMaxEvents: true,
                events: [
                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            title: 'Cita #<?php echo e($cita->id_cita); ?>',
                            start: '<?php echo e($cita->fecha_inicio); ?>',
                            end: '<?php echo e($cita->fecha_fin); ?>'
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            });

            calendar.render();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div id='calendar'></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyappointments\resources\views/cita/calendario.blade.php ENDPATH**/ ?>