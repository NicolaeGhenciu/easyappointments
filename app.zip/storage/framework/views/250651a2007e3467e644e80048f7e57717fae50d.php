<?php $__env->startSection('titulo', 'EasyAppointments'); ?>



<?php $__env->startSection('title'); ?>
    Agenda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('linkScript'); ?>

    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.6/index.global.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {

                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,listDay,listWeek'
                },

                // customize the button names,
                // otherwise they'd all just say "list"
                views: {
                    listDay: {
                        buttonText: 'list day'
                    },
                    listWeek: {
                        buttonText: 'list week'
                    },
                    dayGridMonth: {
                        buttonText: 'month'
                    }
                },

                initialView: 'listDay',
                initialDate: new Date(new Date().getTime() - (new Date().getTimezoneOffset() * 60000))
                    .toISOString().slice(0, 10),
                navLinks: true,
                editable: false,
                dayMaxEvents: true,
                events: [
                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            title: 'Cita #<?php echo e($cita->id_cita); ?>',
                            start: '<?php echo e($cita->fecha_inicio); ?>',
                            end: '<?php echo e($cita->fecha_fin); ?>',
                            //color: 'red',
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],

                eventClick: function(info) {
                    // obtener la información de la cita
                    var title = info.event.title;
                    var start = info.event.start;
                    var end = info.event.end;

                    // mostrar un alert con la información de la cita
                    alert('Cita: ' + title + '\nInicio: ' + start + '\nFin: ' + end);
                }

            });

            calendar.render();
        });
    </script>

    <style>
        #calendar {
            height: 75vh;
            /* el calendario ocupará el 60% de la altura de la pantalla */
        }

        .fc-daygrid-day-number {
            color: black;
            text-decoration: none;
            /* Este estilo desactiva el subrayado de texto que se utiliza para los enlaces hipervínculos */
        }

        .fc-col-header-cell-cushion {
            cursor: default;
            pointer-events: none;
            color: black;
            text-decoration: none;
            /* Este estilo desactiva el subrayado de texto que se utiliza para los enlaces hipervínculos */
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="container">
        <div class="row align-items-center">
            <div class="col-auto">
                <span data-bs-toggle="tooltip" data-bs-placement="top" title="Programar una nueva cita">
                    <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#añadirModal">
                        <i class="bi bi-calendar-plus-fill"></i></a></span>
            </div>
            <div class="col text-center">
                <h3>Agenda - <?php echo e(Auth::user()->nombre); ?></h3>
            </div>
        </div>
    </div>
    <hr>

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>

    <div id='calendar'></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyappointments\resources\views/cita/agendaEmpleado.blade.php ENDPATH**/ ?>