<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CitasController;
use App\Http\Controllers\EmpleadoController;
use App\Http\Controllers\MunicipioController;
use App\Http\Controllers\ServicioController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/enviar-correo', function () {
//     $email = 'nicoadrianx42x@gmail.com'; // Cambia esto por la dirección de correo electrónico de destino
//     $subject = 'Correo electrónico de prueba';
//     $body = 'Este es un correo electrónico de prueba enviado desde Laravel.';
//     Mail::raw($body, function ($message) use ($email, $subject) {
//         $message->from('empresa@gmail.com', 'Tu nombre');
//         $message->to($email)->subject($subject);
//     });
//     return 'El correo electrónico de prueba se ha enviado correctamente.';
// });

//GET Login
Route::get('/', [AuthController::class, 'showLoginForm'])->name('login');

//POST Login
Route::post('/login', [AuthController::class, 'login'])->name('login');

// Dar de alta a una empresa
Route::post('crearUsuarioEmpresa', [UserController::class, 'crearUsuarioEmpresa'])->name('crearUsuarioEmpresa');

// Dar de alta a un cliente
Route::post('crearUsuarioCliente', [UserController::class, 'crearUsuarioCliente'])->name('crearUsuarioCliente');

//Logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

//Peticion JSON
Route::get('/municipiosPorProvincia/{provincia_id}', [MunicipioController::class, 'municipiosPorProvincia']);

//-- Aqui no dejamos acceder a no ser que se haya logueado.
Route::middleware(['auth'])->group(function () {

    //Menu Principal
    Route::get('/easyappointments', function () {
        return view('easyappointments');
    })->name('easyappointments');

    //Rol Empresa
    Route::middleware(['empresa'])->group(function () {

        // --- Empleado

        //Listar
        Route::get('/listarEmpleados', [EmpleadoController::class, 'listar'])->name('listarEmpleados');
        //Dar de alta un empleado
        Route::post('/crearUsuarioEmpleado', [UserController::class, 'crearUsuarioEmpleado'])->name('crearUsuarioEmpleado');
        //Modificar un empleado
        Route::put('/modificarEmpleado/{id}', [EmpleadoController::class, 'modificar'])->name('modificarEmpleado');
        //Borrar un empleado
        Route::delete('/borrarEmpleado/{id}', [EmpleadoController::class, 'borrar'])->name('borrarEmpleado');
        //Servicios que presta un empleado
        Route::get('/serviciosEmpleado/{id}', [EmpleadoController::class, 'servicios'])->name('serviciosEmpleado');
        //Asociar servicios a un empleado
        Route::post('/asociarServicio/{id}', [EmpleadoController::class, 'asociarServicio'])->name('asociarServicio');
        //Eliminar una asociacion-servicios de un empleado
        Route::delete('/desasociarServicio/{id}', [EmpleadoController::class, 'desasociarServicio'])->name('desasociarServicio');

        // --- Servicios

        //Listar
        Route::get('/listarServicios', [ServicioController::class, 'listar'])->name('listarServicios');
        //Dar de alta a un servicio
        Route::post('/crearServicio', [ServicioController::class, 'crear'])->name('crearServicio');
        //Modificar un servicio
        Route::put('/modificarServicio/{id}', [ServicioController::class, 'modificar'])->name('modificarServicio');
        //Borrar un servicio
        Route::delete('/borrarServicio/{id}', [ServicioController::class, 'borrar'])->name('borrarServicio');

        // --- Citas

    });

    //Rol Empelado
    Route::middleware(['empleado'])->group(function () {

        // --- Citas
        //Ver la agenda mensual, semanal y diaria del empleado
        Route::get('/agendaEmpleado', [CitasController::class, 'agendaEmpleado'])->name('agendaEmpleado');
    });
});
